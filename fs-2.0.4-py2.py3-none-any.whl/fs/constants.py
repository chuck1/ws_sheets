"""Constants used by PyFilesystem."""

import io


DEFAULT_CHUNK_SIZE = io.DEFAULT_BUFFER_SIZE * 16
